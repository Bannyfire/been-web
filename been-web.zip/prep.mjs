// Crea countries.json (Natural Earth) e regions.json (geoBoundaries ADM1 + regioni italiane ISTAT)
import fs from "fs";
import { execSync } from "child_process";
const get = (p, k) => { for (const a of Object.keys(p)) if (a.toLowerCase() === k) return p[a]; };
const first = (p, ks) => { for (const k of ks) { const v = get(p, k); if (v !== undefined && v !== null && v !== "") return v; } };
function load(f) { return JSON.parse(fs.readFileSync(f, "utf8")).features.filter(x => x.geometry); }

const C = load("c.json").map(x => {
  const p = x.properties, o = {};
  for (const k of ["adm0_a3", "name", "name_it", "continent", "iso_a2", "iso_a2_eh"]) o[k] = get(p, k);
  return { type: "Feature", properties: o, geometry: x.geometry };
});
let R = load("r.json").map(x => {
  const p = x.properties;
  return { type: "Feature", properties: { id: get(p, "shapeid"), a3: get(p, "shapegroup"), n: get(p, "shapename") }, geometry: x.geometry };
}).filter(x => x.properties.id);

// Italia: le 20 regioni vere (geoBoundaries ADM1 le dà come 5 macro-regioni)
const res = await fetch("https://raw.githubusercontent.com/guglielmo/geojson-italy/main/geojson/limits_IT_regions.geojson");
if (!res.ok) throw new Error("Regioni italiane non scaricate: " + res.status);
fs.writeFileSync("it_in.geojson", Buffer.from(await res.arrayBuffer()));
execSync("npx --yes mapshaper it_in.geojson -simplify 6% keep-shapes -o it.json format=geojson precision=0.001", { stdio: "inherit" });
const itRaw = load("it.json");
console.log("proprieta regioni italiane:", JSON.stringify(itRaw[0].properties));
const IT = itRaw.map(x => {
  const p = x.properties;
  const n = first(p, ["reg_name", "den_reg", "nome", "name", "denominazione"]);
  const code = first(p, ["reg_istat_code_num", "reg_istat_code", "cod_reg"]) ?? n;
  return { type: "Feature", properties: { id: "ITA-R" + code, a3: "ITA", n: String(n) }, geometry: x.geometry };
});
if (IT.length < 15 || IT.length > 25) throw new Error("Regioni italiane inattese: " + IT.length);
R = R.filter(x => x.properties.a3 !== "ITA").concat(IT);

console.log("paesi", C.length, "regioni", R.length, "(Italia:", IT.length + ")");
if (C.length < 150 || R.length < 500) throw new Error("Dati insufficienti: paesi " + C.length + ", regioni " + R.length);
fs.writeFileSync("countries.json", JSON.stringify({ type: "FeatureCollection", features: C }));
fs.writeFileSync("regions.json", JSON.stringify({ type: "FeatureCollection", features: R }));
